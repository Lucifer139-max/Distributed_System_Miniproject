$ErrorActionPreference = "Stop"
$nodes = @(
  @{id="node-1"; facility="Admin Block"; port=8101},
  @{id="node-2"; facility="Computer Lab"; port=8102},
  @{id="node-3"; facility="Library"; port=8103},
  @{id="node-4"; facility="Hostel"; port=8104},
  @{id="node-5"; facility="Research Center"; port=8105},
  @{id="node-6"; facility="Sports Complex"; port=8106}
)
foreach ($n in $nodes) {
  Start-Process -FilePath "python" -ArgumentList @("-m","app.nodes.agent","--id",$n.id,"--facility",$n.facility,"--port",$n.port) -WorkingDirectory "$PSScriptRoot/../backend" -WindowStyle Normal
}
Write-Host "Started six independent node processes. API must already be running at http://127.0.0.1:8000."
