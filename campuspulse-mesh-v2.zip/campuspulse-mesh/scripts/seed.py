from app.database import Base, engine, SessionLocal
from app.seed import seed
Base.metadata.create_all(bind=engine)
db=SessionLocal()
try:
    seed(db)
    print("CampusPulse Mesh seed data is ready.")
finally:
    db.close()
