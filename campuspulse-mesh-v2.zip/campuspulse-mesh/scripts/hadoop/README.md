# Apache Hadoop Streaming integration (Unit IV)

CampusPulse exports real stored system events and message events to JSON Lines using `POST /api/hadoop/export`. The mapper emits `event_type/category<TAB>1`; the reducer sums counts. The job runs as an actual Hadoop Streaming MapReduce job on a configured Hadoop cluster.

Prerequisites: Python 3, Hadoop client commands (`hadoop`, `hdfs`), access to HDFS, and the Hadoop Streaming JAR. Set `HADOOP_STREAMING_JAR=/path/to/hadoop-streaming-<version>.jar`. Then:

1. Call `POST http://127.0.0.1:8000/api/hadoop/export`.
2. From repository root run `bash scripts/hadoop/run_hadoop_streaming.sh`.

The Hadoop cluster is external and is not bundled in this repository; Hadoop jobs have not been run in this environment. This is an executable integration, not a claim that Hadoop is already deployed.
