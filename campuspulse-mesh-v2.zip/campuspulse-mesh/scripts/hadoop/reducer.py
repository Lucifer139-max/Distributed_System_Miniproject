#!/usr/bin/env python3
import sys
current=None; total=0
for line in sys.stdin:
    try: key,value=line.rstrip('\n').split('\t',1); value=int(value)
    except Exception: continue
    if current is not None and key!=current:
        print(f"{current}\t{total}"); total=0
    current=key; total+=value
if current is not None: print(f"{current}\t{total}")
