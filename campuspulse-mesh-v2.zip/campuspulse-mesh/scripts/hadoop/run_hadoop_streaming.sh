#!/usr/bin/env bash
# Run after POST /api/hadoop/export and with Hadoop CLI + hadoop-streaming jar configured.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
INPUT="$ROOT/data/hadoop/campus_events.jsonl"
HDFS_INPUT="${HDFS_INPUT:-/campuspulse/input/campus_events.jsonl}"
HDFS_OUTPUT="${HDFS_OUTPUT:-/campuspulse/output/event_counts_$(date +%s)}"
STREAMING_JAR="${HADOOP_STREAMING_JAR:-}"
if [[ -z "$STREAMING_JAR" ]]; then echo 'Set HADOOP_STREAMING_JAR to the Hadoop streaming jar path.' >&2; exit 2; fi
hdfs dfs -mkdir -p "$(dirname "$HDFS_INPUT")"
hdfs dfs -put -f "$INPUT" "$HDFS_INPUT"
hadoop jar "$STREAMING_JAR" -input "$HDFS_INPUT" -output "$HDFS_OUTPUT" -mapper "$ROOT/scripts/hadoop/mapper.py" -reducer "$ROOT/scripts/hadoop/reducer.py" -file "$ROOT/scripts/hadoop/mapper.py" -file "$ROOT/scripts/hadoop/reducer.py"
hdfs dfs -cat "$HDFS_OUTPUT/part-*"
echo "Hadoop output stored at $HDFS_OUTPUT"
