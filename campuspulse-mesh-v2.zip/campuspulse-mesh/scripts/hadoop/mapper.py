#!/usr/bin/env python3
import sys,json
for line in sys.stdin:
    try:
        row=json.loads(line)
        key=row.get('event_type') or row.get('category') or row.get('kind','unknown')
        print(f"{key}\t1")
    except Exception:
        continue
