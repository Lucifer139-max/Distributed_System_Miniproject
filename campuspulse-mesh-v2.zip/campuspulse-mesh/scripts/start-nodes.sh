#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../backend"
python -m app.nodes.agent --id node-1 --facility "Admin Block" --port 8101 &
python -m app.nodes.agent --id node-2 --facility "Computer Lab" --port 8102 &
python -m app.nodes.agent --id node-3 --facility "Library" --port 8103 &
python -m app.nodes.agent --id node-4 --facility "Hostel" --port 8104 &
python -m app.nodes.agent --id node-5 --facility "Research Center" --port 8105 &
python -m app.nodes.agent --id node-6 --facility "Sports Complex" --port 8106 &
echo "Started six independent node processes; press Ctrl+C to stop this shell (child process cleanup may vary by OS)."
wait
