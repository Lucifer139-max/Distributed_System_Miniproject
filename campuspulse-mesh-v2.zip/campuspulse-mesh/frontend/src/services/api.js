const BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000'
export async function api(path, options={}) {
  const response = await fetch(`${BASE}${path}`, {headers:{'Content-Type':'application/json',...(options.headers||{})},...options})
  const body = await response.json().catch(()=>({detail:response.statusText}))
  if (!response.ok) throw new Error(typeof body.detail==='string'?body.detail:body.detail?.message||'Request failed')
  return body
}
