import React from 'react'
import {describe,it,expect,vi} from 'vitest'
import {render,screen} from '@testing-library/react'
import Layout from './Layout'

describe('Layout',()=>{
  it('renders CampusPulse navigation and admin shell',()=>{
    render(<Layout page="Dashboard" setPage={vi.fn()} nodeSummary={{offline:0}} search="" setSearch={vi.fn()}><div>Dashboard content</div></Layout>)
    expect(screen.getByText('CampusPulse Mesh')).toBeInTheDocument()
    expect(screen.getByText('Dashboard')).toBeInTheDocument()
    expect(screen.getByText('System Administrator')).toBeInTheDocument()
  })
})
