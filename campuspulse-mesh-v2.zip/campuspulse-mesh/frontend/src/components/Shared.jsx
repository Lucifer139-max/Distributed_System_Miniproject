import React from 'react'
import { Plus, RefreshCw, AlertTriangle, Database, Building2, CheckCircle2, Clock3, Users, MapPin, Wrench, Eye, CalendarDays, Search } from 'lucide-react'
export function PageTitle({icon:Icon=Building2,title,subtitle,action,actionText,onAction}) { return <div className="page-title"><div className="title-icon"><Icon size={28}/></div><div className="title-copy"><h1>{title}</h1><p>{subtitle}</p></div>{actionText&&<button className="primary-btn title-action" onClick={onAction}>{action==='refresh'?<RefreshCw size={17}/>:<Plus size={18}/>} {actionText}</button>}</div> }
export function Stat({icon:Icon,label,value,detail,tone='blue'}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={25}/></div><div><span>{label}</span><strong>{value}</strong><small>{detail}</small></div></div> }
export function Badge({children,tone='green'}) {return <span className={`badge ${tone}`}>{children}</span>}
export function Modal({title,onClose,children}) {return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><div className="modal"><div className="modal-head"><h2>{title}</h2><button className="close" onClick={onClose}>×</button></div>{children}</div></div>}
export function Empty({text='No records found'}) {return <div className="empty-state"><Search size={26}/><p>{text}</p></div>}
export const fmt=(d)=>d?new Date(d).toLocaleString():'—'
