# CampusPulse Mesh
**Fault-Tolerant Distributed Campus Resource Coordination System** — React/Vite + FastAPI + SQLAlchemy + PostgreSQL, with independent HTTP node agents.

This repository is a runnable academic implementation of the supplied specification and UI references. It contains four primary pages (Dashboard, Facilities, Nodes, Incidents) plus Reservations, Messages, System Logs, Analytics, Snapshots and Settings.

## Architecture
- `frontend/`: React + Vite, Recharts, Lucide icons; responsive dashboard UI.
- `backend/app/main.py`: FastAPI REST API, persistence, monitoring loop, reservations, incidents, election and snapshot endpoints.
- `backend/app/nodes/agent.py`: each invocation is an independent HTTP process with a `/health`, `/message`, and `/tick` endpoint, registration and heartbeat loop.
- `backend/app/algorithms/`: Bully election decision, Lamport logical clock, wait-for graph cycle detection.
- `backend/app/models.py`: SQLAlchemy entities for facilities, resources, nodes, reservations, incidents, messages, events, elections, snapshots, pending updates and dependencies.
- PostgreSQL is the recommended persistent database. SQLite is the default local fallback so the project can start without Docker/PostgreSQL.

## Requirements
- Python 3.11+ recommended
- Node.js 20+ and npm
- Docker Desktop (optional; for PostgreSQL)

## Start locally (SQLite, fastest)
Commands below assume the repository root.

### 1. Backend
**Windows PowerShell**
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:DATABASE_URL = "sqlite:///./campuspulse.db"
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

**macOS/Linux**
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL=sqlite:///./campuspulse.db
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
The API creates tables and inserts demonstration facilities/incidents/nodes at startup. A baseline Alembic migration is also included (`cd backend && alembic upgrade head`) for schema setup/versioning. API docs: http://127.0.0.1:8000/docs

### 2. Start six independent node processes
Open a second terminal at repository root:
```bash
# macOS/Linux
cd backend
source .venv/bin/activate
cd ..
bash scripts/start-nodes.sh
```
Windows PowerShell (run from repository root, with backend virtualenv activated in the current shell):
```powershell
.\scripts\start-nodes.ps1
```
For just three nodes, run the following commands in three terminals from `backend/` after activating the virtualenv:
```bash
python -m app.nodes.agent --id node-1 --facility "Admin Block" --port 8101
python -m app.nodes.agent --id node-2 --facility "Computer Lab" --port 8102
python -m app.nodes.agent --id node-3 --facility "Library" --port 8103
```
Each process can be independently terminated/restarted. Heartbeats are sent to the API at the configured interval.

### 3. Frontend
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL printed by npm, normally http://localhost:5173. If the API is elsewhere, set `VITE_API_URL` before starting Vite, e.g. `VITE_API_URL=http://127.0.0.1:8000`.

### 4. PostgreSQL with Docker (recommended for concurrency tests)
At repository root:
```bash
docker compose up -d postgres
```
Then start the API with a PostgreSQL URL instead of SQLite:
```bash
# Windows PowerShell from backend/
$env:DATABASE_URL = "postgresql+psycopg://campuspulse:campuspulse_dev_only@localhost:5432/campuspulse"
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
```bash
# macOS/Linux from backend/
export DATABASE_URL=postgresql+psycopg://campuspulse:campuspulse_dev_only@localhost:5432/campuspulse
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
The credentials in compose are development-only. Do not use them in production. Copy `.env.example` to `.env` and use private credentials for anything beyond a local demonstration.

### Tests
```bash
cd backend
python -m pytest -q
```
Frontend production build:
```bash
cd frontend
npm install
npm run build
```

## API highlights
- `GET /api/dashboard`, `GET /api/facilities`, `GET /api/resources`
- `GET/POST /api/reservations`, `POST /api/reservations/{id}/cancel`
- `GET/POST /api/incidents`, `PATCH /api/incidents/{id}`
- `GET /api/nodes`, `POST /api/nodes/register`, `POST /api/nodes/{id}/heartbeat`
- `POST /api/nodes/{id}/stop`, `POST /api/nodes/{id}/restart`, `POST /api/nodes/{id}/test-failure`
- `POST /api/elections`, `GET /api/coordinator`, `GET /api/messages`, `GET /api/logs`
- `POST/GET /api/snapshots`, `POST /api/dependencies`, `GET /api/deadlocks`, `GET /api/analytics`

## Distributed systems implementation and honest limitations
- **Independent nodes and service discovery:** implemented as separate Uvicorn processes; nodes register over HTTP and periodically send heartbeats.
- **Heartbeat failure detection:** API monitoring marks a node offline after the configured timeout and opens an incident. Network partitions can be mistaken for failures, as in common heartbeat-based detectors.
- **Bully election:** implemented decision logic selects the highest-priority online node and persists the election result. The API emits election-announcement message records. The current implementation does **not** run the full classic peer-to-peer election/OK/coordinator exchange as an entirely node-originated protocol; it is an API-orchestrated Bully election demonstration.
- **Lamport clocks:** each node ticks its local clock and advances it when it receives an HTTP message. Node heartbeats report clock values. Current dashboard data shows clocks from agent state reported to API.
- **Reservation mutual exclusion:** overlapping bookings are rejected server-side. PostgreSQL mode uses a per-resource transaction advisory lock plus overlap check/row locks. This provides a single-database serialization point, not a fully replicated Ricart–Agrawala-style distributed mutual exclusion protocol. SQLite mode is for local UI/testing and should not be used to validate high-contention multi-process correctness.
- **Snapshots:** captures current reachable node state, confirmed reservation count and recent messages. It is explicitly labelled **best-effort**, not a formally consistent Chandy–Lamport snapshot, because all in-flight HTTP channels are not instrumented.
- **Deadlock detection:** wait-for graph dependencies can be added through `POST /api/dependencies`; cycle detection returns detected cycles.
- **Recovery:** node agents re-register after startup and reconcile the registry's reachable status. A durable, replicated event replay queue with version conflict resolution is not yet implemented; the schema includes `PendingUpdate` for extension.
- **Metrics:** node agent heartbeat currently reports zero CPU/memory placeholders unless the payload is extended to report process metrics. These are not presented as real measurements. Latency is currently a stored metric and is not yet measured by the agent heartbeat handler.
- **Database migrations:** models and `create_all` are provided for easy local startup; a versioned Alembic migration history has not been added.
- **Authentication/authorization:** the demo admin interface has no login/authentication. Do not expose the API to untrusted networks.
- **External imagery:** cards use remote Unsplash image URLs for visual fidelity; local fallback styling remains but the images are not bundled locally. An offline deployment should replace them with local assets.
- **Automated verification:** algorithm tests cover Lamport clock rules, Bully winner selection and deadlock cycles. API tests exercise health/facility retrieval and deadlock endpoint. End-to-end process failure, PostgreSQL concurrent booking and UI browser automation require a running environment and should be demonstrated manually.

## Suggested manual demo
1. Start API, then start three or six node processes. Open `/api/nodes` or the Nodes page and confirm online heartbeats.
2. Stop one node process in its terminal. Wait longer than `HEARTBEAT_TIMEOUT_SECONDS` (default 10 seconds). Observe offline status and the generated incident.
3. Use **Test Failure** or `POST /api/elections` to demonstrate election result and coordinator event. Note: Test Failure marks the registry state offline; it does not kill the process.
4. Submit two reservations for the same resource and overlapping intervals. The second should receive HTTP 409.
5. Add wait-for edges using `POST /api/dependencies`, e.g. `{"waiter":"A","holder":"B","resource":"lab"}` and `{"waiter":"B","holder":"A","resource":"printer"}`. `GET /api/deadlocks` should report a cycle.
6. Create a snapshot and inspect the recorded best-effort state.
7. Restart a previously stopped process. It should register and heartbeat again; if the registry was only marked offline while the process remained alive, the next heartbeat restores online status.

## UI reference notes
The app follows the supplied dark-navy sidebar, white topbar, bright-blue actions, rounded cards, status badges, facility grid, node table/topology, incident table/detail pane, and dashboard map/activity layout. At narrow widths, the sidebar collapses and tables scroll horizontally.


## Extended syllabus implementation (v2)

### Unit II additions
- **Database-backed message queue:** `POST /api/broker/publish`, `GET /api/broker/consume/{receiver}`, `GET /api/broker/messages`. Messages persist and are consumed by node agents. This is a broker-style queue pattern built on the existing database, not a RabbitMQ/Kafka broker.
- **Direct peer-to-peer HTTP:** `POST /api/p2p/send` sends to a peer node's registered address.
- **WebRTC media:** `/api/webrtc/{room}/{client_id}` relays signaling messages. The Distributed Lab UI obtains local camera/microphone access and negotiates a peer connection. Actual media transfer requires browser permissions and a second browser/device; STUN is configured but TURN is not bundled.

### Unit III additions
- **Vector clocks:** `/api/clocks/vector/tick`, `/receive`, `/compare`; node agents include vector clocks in health state and merge remote vector state on received messages.
- **Fair FIFO mutual exclusion:** `/api/mutex/request`, `/release`, `/status` provides ticket-ordered, starvation-resistant lock granting within one API process. This is a fair FIFO educational algorithm, not a verified implementation of the published Lodha–Kshemkalyani protocol. Do not use multiple API workers with this in-memory lock.
- **Deadlock detection classification:** `/api/deadlocks/classification` describes centralized, hierarchical and fully distributed families plus Knapp-style path-pushing, edge-chasing, diffusion-computation and global-state detection categories. Only the centralized global wait-for graph detector runs; the other families are syllabus comparisons.

### Unit IV addition: Apache Hadoop
- `POST /api/hadoop/export` exports stored system events and message events to `data/hadoop/campus_events.jsonl`.
- `scripts/hadoop/mapper.py` and `reducer.py` implement a Hadoop Streaming MapReduce job that counts event categories/types.
- `scripts/hadoop/run_hadoop_streaming.sh` uploads input to HDFS and executes the job using a configured Hadoop Streaming JAR. See `scripts/hadoop/README.md`.
- Hadoop requires an external cluster/client installation and has not been run in this environment. The export endpoint and job scripts are provided; do not claim the cluster job was tested.

The new **Distributed Lab** frontend page exposes queue messaging, peer HTTP messaging, vector clock operations, fair mutex, WebRTC room setup, Hadoop export, and deadlock-family classification.

### Updated test coverage
New unit tests cover vector-clock causality and FIFO mutex ordering. API tests cover the broker queue, vector-clock endpoints, fair mutex, and Hadoop export endpoint. Browser WebRTC negotiation and the Hadoop MapReduce job require their external runtime dependencies and remain manual integration checks.
