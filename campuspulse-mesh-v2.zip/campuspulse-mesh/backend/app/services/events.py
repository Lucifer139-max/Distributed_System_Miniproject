import json, uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from ..models import SystemEvent, MessageEvent

def log_event(db: Session, category: str, message: str, node_id: str | None = None):
    db.add(SystemEvent(event_id=str(uuid.uuid4()), category=category, message=message, node_id=node_id,
                       timestamp=datetime.now(timezone.utc)))
    db.commit()

def log_message(db: Session, sender: str, receiver: str, event_type: str, clock: int = 0,
                outcome: str = "ok", payload: dict | None = None):
    db.add(MessageEvent(event_id=str(uuid.uuid4()), sender=sender, receiver=receiver, event_type=event_type,
                        clock_value=clock, outcome=outcome, payload=json.dumps(payload or {}),
                        timestamp=datetime.now(timezone.utc)))
    db.commit()
