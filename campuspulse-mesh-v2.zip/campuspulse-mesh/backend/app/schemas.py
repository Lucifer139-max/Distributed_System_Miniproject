from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict

class ReservationCreate(BaseModel):
    requester: str = Field(min_length=1, max_length=120)
    resource_id: int
    start_at: datetime
    end_at: datetime
    purpose: str = Field(min_length=2, max_length=1000)

class IncidentCreate(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    severity: str = "Medium"
    facility: str
    reported_by: str = "Admin"
    description: str = ""

class IncidentUpdate(BaseModel):
    status: str | None = None
    assigned_to: str | None = None

class NodeRegister(BaseModel):
    id: str
    facility: str
    address: str
    priority: int

class DependencyCreate(BaseModel):
    waiter: str
    holder: str
    resource: str
