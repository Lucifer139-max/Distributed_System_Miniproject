from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta
import json, uuid, asyncio
import httpx
import requests
from fastapi import FastAPI, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func
from .database import Base, engine, get_db, SessionLocal
from .models import Facility, Resource, Reservation, DistributedNode, Incident, MessageEvent, SystemEvent, CoordinatorElection, Snapshot, ResourceDependency, QueuedMessage, FairMutexTicket
from .schemas import ReservationCreate, IncidentCreate, IncidentUpdate, NodeRegister, DependencyCreate
from .seed import seed
from .config import settings
from .services.events import log_event, log_message
from .algorithms.bully import bully_election
from .algorithms.deadlock import find_cycles
from .algorithms.vector_clock import tick as vector_tick, merge_on_receive, compare as compare_vectors
from .algorithms.deadlock_classification import classify_detection
from .algorithms.fair_mutex import FairMutex

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    db=SessionLocal()
    try: seed(db)
    finally: db.close()
    task=asyncio.create_task(monitor_nodes())
    yield
    task.cancel()

app=FastAPI(title="CampusPulse Mesh API", version="2.0.0", lifespan=lifespan)
fair_mutex=FairMutex()
webrtc_rooms: dict[str, dict[str, WebSocket]] = {}

app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173","http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def dt(value):
    return value.isoformat() if value else None

def node_dict(n):
    hb=n.last_heartbeat
    age=(datetime.now(timezone.utc)-hb.replace(tzinfo=timezone.utc) if hb and hb.tzinfo is None else datetime.now(timezone.utc)-hb) if hb else None
    return {"id":n.id,"facility":n.facility,"address":n.address,"status":n.status,"priority":n.priority,
            "last_heartbeat":dt(hb),"heartbeat_age_seconds":round(age.total_seconds(),1) if age else None,
            "clock_value":n.clock_value,"cpu_percent":n.cpu_percent,"memory_percent":n.memory_percent,
            "latency_ms":n.latency_ms,"version":n.version,"last_error":n.last_error}

async def monitor_nodes():
    while True:
        db=SessionLocal()
        try:
            now=datetime.now(timezone.utc)
            nodes=db.query(DistributedNode).all()
            changed=[]
            for n in nodes:
                hb=n.last_heartbeat
                if hb and hb.tzinfo is None: hb=hb.replace(tzinfo=timezone.utc)
                if n.status=="online" and (not hb or (now-hb).total_seconds()>settings.heartbeat_timeout_seconds):
                    n.status="offline"; n.last_error="Heartbeat timeout"; changed.append(n.id)
            db.commit()
            for nid in changed:
                log_event(db,"node_failure",f"{nid} marked offline after heartbeat timeout",nid)
                if not db.query(Incident).filter(Incident.title==f"Node {nid} offline", Incident.status!="Resolved").first():
                    node=db.get(DistributedNode,nid)
                    db.add(Incident(title=f"Node {nid} offline",severity="High",facility=node.facility if node else nid,
                                    reported_by="Heartbeat Monitor",status="Open",description="Node heartbeat exceeded configured timeout"))
                    db.commit()
                if any(n.id == nid for n in nodes):
                    try: elect_coordinator(db,nid,"node failure")
                    except Exception: pass
        except Exception:
            db.rollback()
        finally: db.close()
        await asyncio.sleep(2)

@app.get("/api/health")
def api_health(db: Session=Depends(get_db)):
    return {"status":"ok","database":"connected","nodes_total":db.query(DistributedNode).count()}

@app.get("/api/dashboard")
def dashboard(db: Session=Depends(get_db)):
    nodes=db.query(DistributedNode).all()
    facilities=db.query(Facility).count()
    ongoing=db.query(Reservation).filter(Reservation.status=="confirmed",Reservation.end_at>datetime.now(timezone.utc)).count()
    open_inc=db.query(Incident).filter(Incident.status!="Resolved").count()
    events=db.query(SystemEvent).order_by(SystemEvent.timestamp.desc()).limit(8).all()
    return {"total_facilities":facilities,"active_nodes":sum(n.status=="online" for n in nodes),"total_nodes":len(nodes),
            "ongoing_reservations":ongoing,"open_incidents":open_inc,"coordinator":get_coordinator(db),
            "nodes":[node_dict(n) for n in nodes],
            "recent_activity":[{"id":e.id,"category":e.category,"message":e.message,"node_id":e.node_id,"timestamp":dt(e.timestamp)} for e in events]}

@app.get("/api/facilities")
def facilities(category: str | None=None, q: str | None=None, db: Session=Depends(get_db)):
    query=db.query(Facility)
    if category and category not in ("All Facilities","All"): query=query.filter(Facility.category==category)
    if q: query=query.filter(or_(Facility.name.ilike(f"%{q}%"),Facility.location.ilike(f"%{q}%"),Facility.equipment.ilike(f"%{q}%")))
    return [{"id":f.id,"name":f.name,"category":f.category,"capacity":f.capacity,"location":f.location,"equipment":f.equipment,
             "image_key":f.image_key,"node_id":f.node_id,
             "status":"Maintenance" if "Electronics" in f.name else ("In Use" if "Lab 2" in f.name or "Hostel" in f.name else "Available")} for f in query.order_by(Facility.id)]

@app.get("/api/resources")
def resources(db: Session=Depends(get_db)):
    return [{"id":r.id,"name":r.name,"facility_id":r.facility_id,"capacity":r.capacity,"kind":r.kind} for r in db.query(Resource).all()]

@app.get("/api/reservations")
def reservations(status: str | None=None, db: Session=Depends(get_db)):
    q=db.query(Reservation)
    if status: q=q.filter(Reservation.status==status)
    return [{"id":r.id,"requester":r.requester,"resource_id":r.resource_id,"facility":r.facility_name,"start_at":dt(r.start_at),
             "end_at":dt(r.end_at),"purpose":r.purpose,"status":r.status,"request_id":r.request_id} for r in q.order_by(Reservation.start_at.desc()).all()]

@app.post("/api/reservations", status_code=201)
async def create_reservation(data: ReservationCreate, db: Session=Depends(get_db)):
    if data.end_at <= data.start_at: raise HTTPException(422,"End time must be after start time")
    if data.start_at < datetime.now(timezone.utc)-timedelta(minutes=1): raise HTTPException(422,"Reservation must be in the future")
    resource=db.get(Resource,data.resource_id)
    if not resource: raise HTTPException(404,"Resource not found")
    facility=db.get(Facility,resource.facility_id)
    # PostgreSQL transaction serializes reservation checks per resource with an advisory lock.
    # SQLite local mode uses an immediate transaction and the same overlap predicate.
    try:
        if engine.dialect.name=="postgresql":
            db.execute(func.pg_advisory_xact_lock(resource.id))
        conflicts=db.query(Reservation).filter(Reservation.resource_id==resource.id,Reservation.status=="confirmed",
            Reservation.start_at<data.end_at,Reservation.end_at>data.start_at).with_for_update().all()
        if conflicts: raise HTTPException(409,detail={"message":"Resource is already reserved for an overlapping time slot","conflicting_reservations":[r.id for r in conflicts]})
        request_id=str(uuid.uuid4())
        row=Reservation(requester=data.requester,resource_id=resource.id,facility_name=facility.name,start_at=data.start_at,
                        end_at=data.end_at,purpose=data.purpose,status="confirmed",request_id=request_id)
        db.add(row); db.commit(); db.refresh(row)
        log_event(db,"reservation",f"Reservation #{row.id} created for {facility.name}")
        log_message(db,"api",facility.node_id or "node-registry","ReservationGranted",payload={"reservation_id":row.id,"resource_id":resource.id})
        return {"id":row.id,"status":row.status,"request_id":row.request_id,"message":"Reservation confirmed"}
    except HTTPException: db.rollback(); raise
    except Exception as exc: db.rollback(); raise HTTPException(500,f"Reservation failed: {exc}")

@app.post("/api/reservations/{reservation_id}/cancel")
def cancel_reservation(reservation_id:int, db:Session=Depends(get_db)):
    r=db.get(Reservation,reservation_id)
    if not r: raise HTTPException(404,"Reservation not found")
    r.status="cancelled"; db.commit(); log_event(db,"reservation",f"Reservation #{r.id} cancelled")
    return {"status":"cancelled"}

@app.get("/api/nodes")
def nodes(db:Session=Depends(get_db)):
    return [node_dict(n) for n in db.query(DistributedNode).order_by(DistributedNode.priority).all()]

@app.post("/api/nodes/register")
def register_node(data:NodeRegister, db:Session=Depends(get_db)):
    n=db.get(DistributedNode,data.id)
    if n:
        n.facility=data.facility; n.address=data.address; n.priority=data.priority; n.status="online"; n.last_error=""; n.version+=1
    else:
        n=DistributedNode(id=data.id,facility=data.facility,address=data.address,priority=data.priority,status="online",version=1)
        db.add(n)
    db.commit(); log_event(db,"node_registered",f"{data.id} registered at {data.address}",data.id)
    return {"registered":True,"node":node_dict(n)}

@app.post("/api/nodes/{node_id}/heartbeat")
def heartbeat(node_id:str, payload:dict, db:Session=Depends(get_db)):
    n=db.get(DistributedNode,node_id)
    if not n: raise HTTPException(404,"Node must register before heartbeat")
    n.status="online"; n.last_heartbeat=datetime.now(timezone.utc); n.clock_value=max(n.clock_value,int(payload.get("clock_value",0)))
    n.cpu_percent=float(payload.get("cpu_percent",0)); n.memory_percent=float(payload.get("memory_percent",0)); n.latency_ms=float(payload.get("latency_ms",0)); n.last_error=""
    db.commit()
    log_message(db,node_id,"api","Heartbeat",clock=n.clock_value,payload={"status":"online"})
    return {"acknowledged":True,"node_id":node_id,"clock_value":n.clock_value}

@app.post("/api/nodes/{node_id}/stop")
async def stop_node(node_id:str, db:Session=Depends(get_db)):
    n=db.get(DistributedNode,node_id)
    if not n: raise HTTPException(404,"Node not found")
    # Real node process is not owned by API; the API marks it administratively unavailable.
    # For real process stop, terminate the corresponding process from the terminal.
    n.status="offline"; n.last_error="Administratively marked offline"; db.commit()
    log_event(db,"node_stopped",f"{node_id} marked offline by administrator",node_id)
    return {"status":"offline","note":"To stop the actual process, terminate its terminal/process; heartbeat timeout will also detect it."}

@app.post("/api/nodes/{node_id}/restart")
async def restart_node(node_id:str, db:Session=Depends(get_db)):
    n=db.get(DistributedNode,node_id)
    if not n: raise HTTPException(404,"Node not found")
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            response=await client.get(n.address+"/health")
            response.raise_for_status()
            h=response.json()
        n.status="online"; n.last_heartbeat=datetime.now(timezone.utc); n.clock_value=max(n.clock_value,int(h.get("clock",0))); n.last_error=""
        db.commit(); log_event(db,"node_recovered",f"{node_id} health check succeeded; reconciliation completed",node_id)
        return {"status":"online","health":h,"reconciliation":"no pending writes to replay"}
    except Exception:
        raise HTTPException(503,detail=f"Node process is not reachable at {n.address}; start its process first")

@app.post("/api/nodes/{node_id}/test-failure")
def test_failure(node_id:str, db:Session=Depends(get_db)):
    n=db.get(DistributedNode,node_id)
    if not n: raise HTTPException(404,"Node not found")
    n.status="offline"; n.last_error="Injected test failure"; db.commit()
    log_event(db,"node_failure",f"Test failure injected for {node_id}",node_id)
    if not db.query(Incident).filter(Incident.title==f"Node {node_id} offline",Incident.status!="Resolved").first():
        db.add(Incident(title=f"Node {node_id} offline",severity="High",facility=n.facility,reported_by="Test Failure",status="Open",description="Failure injected through admin controls")); db.commit()
    result=None
    try: result=elect_coordinator(db,node_id,"test failure")
    except Exception as e: result={"error":str(e)}
    return {"status":"offline","election":result}

@app.get("/api/nodes/{node_id}")
def node_detail(node_id:str, db:Session=Depends(get_db)):
    n=db.get(DistributedNode,node_id)
    if not n: raise HTTPException(404,"Node not found")
    return node_dict(n)

def get_coordinator(db):
    rows=db.query(CoordinatorElection).order_by(CoordinatorElection.timestamp.desc()).first()
    if rows and db.get(DistributedNode,rows.coordinator) and db.get(DistributedNode,rows.coordinator).status=="online": return rows.coordinator
    online=db.query(DistributedNode).filter(DistributedNode.status=="online").all()
    return max(online,key=lambda n:n.priority).id if online else None

def elect_coordinator(db,initiator_id,reason="manual"):
    nodes=[{"id":n.id,"status":n.status,"priority":n.priority,"address":n.address,"clock_value":n.clock_value} for n in db.query(DistributedNode).all()]
    result=bully_election(nodes,initiator_id if initiator_id in {n["id"] for n in nodes if n["status"]=="online"} else next(n["id"] for n in nodes if n["status"]=="online"))
    winner=result["coordinator"]
    election=CoordinatorElection(initiator=initiator_id,coordinator=winner,participants=json.dumps(result["participants"]),reason=reason)
    db.add(election); db.commit()
    log_event(db,"coordinator_election",f"Bully election completed: {winner} is coordinator (reason: {reason})",winner)
    for n in nodes:
        if n["status"]=="online":
            outcome="ok"
            remote_clock=0
            try:
                response=requests.post(n.get("address", "")+"/message", json={
                    "sender":initiator_id, "event_type":"COORDINATOR_ANNOUNCEMENT",
                    "clock_value":int(next((x.clock_value for x in db.query(DistributedNode).all() if x.id==initiator_id),0)),
                    "payload":{"coordinator":winner,"reason":reason}}, timeout=0.8)
                response.raise_for_status()
                remote_clock=int(response.json().get("clock",0))
            except Exception:
                outcome="unreachable"
            log_message(db,initiator_id,n["id"],"COORDINATOR_ANNOUNCEMENT",clock=remote_clock,outcome=outcome,
                        payload={"coordinator":winner,"reason":reason})
            if outcome=="ok":
                target=db.get(DistributedNode,n["id"])
                if target: target.clock_value=max(target.clock_value,remote_clock)
    db.commit()
    return {"coordinator":winner,"participants":result["participants"],"algorithm":"Bully","network_broadcast":True}

@app.post("/api/elections")
def trigger_election(payload:dict|None=None, db:Session=Depends(get_db)):
    nodes=db.query(DistributedNode).filter(DistributedNode.status=="online").all()
    if not nodes: raise HTTPException(503,"No online nodes")
    initiator=(payload or {}).get("initiator",nodes[0].id)
    if not db.get(DistributedNode,initiator) or db.get(DistributedNode,initiator).status!="online": initiator=nodes[0].id
    return elect_coordinator(db,initiator,"manual")

@app.get("/api/coordinator")
def coordinator(db:Session=Depends(get_db)):
    return {"coordinator":get_coordinator(db)}

@app.get("/api/messages")
def messages(limit:int=Query(100,ge=1,le=500), db:Session=Depends(get_db)):
    rows=db.query(MessageEvent).order_by(MessageEvent.timestamp.desc()).limit(limit).all()
    return [{"id":m.id,"event_id":m.event_id,"sender":m.sender,"receiver":m.receiver,"event_type":m.event_type,
             "timestamp":dt(m.timestamp),"clock_value":m.clock_value,"outcome":m.outcome,"payload":m.payload} for m in rows]

@app.get("/api/logs")
def logs(limit:int=Query(100,ge=1,le=500), q:str|None=None, db:Session=Depends(get_db)):
    query=db.query(SystemEvent)
    if q: query=query.filter(or_(SystemEvent.message.ilike(f"%{q}%"),SystemEvent.category.ilike(f"%{q}%")))
    rows=query.order_by(SystemEvent.timestamp.desc()).limit(limit).all()
    return [{"id":e.id,"event_id":e.event_id,"category":e.category,"message":e.message,"node_id":e.node_id,"timestamp":dt(e.timestamp)} for e in rows]

@app.get("/api/incidents")
def incidents(status:str|None=None, facility:str|None=None, severity:str|None=None, db:Session=Depends(get_db)):
    q=db.query(Incident)
    if status and status!="All": q=q.filter(Incident.status==status)
    if facility and facility!="All Facilities": q=q.filter(Incident.facility==facility)
    if severity and severity!="All Severities": q=q.filter(Incident.severity==severity)
    rows=q.order_by(Incident.created_at.desc()).all()
    return [{"id":i.id,"title":i.title,"severity":i.severity,"facility":i.facility,"reported_by":i.reported_by,
             "status":i.status,"description":i.description,"assigned_to":i.assigned_to,"created_at":dt(i.created_at),"updated_at":dt(i.updated_at)} for i in rows]

@app.post("/api/incidents",status_code=201)
def create_incident(data:IncidentCreate,db:Session=Depends(get_db)):
    if data.severity not in ("Low","Medium","High","Critical"): raise HTTPException(422,"Invalid severity")
    row=Incident(title=data.title,severity=data.severity,facility=data.facility,reported_by=data.reported_by,status="Open",description=data.description)
    db.add(row); db.commit(); db.refresh(row); log_event(db,"incident",f"Incident #{row.id} reported: {row.title}")
    return {"id":row.id,"status":row.status}

@app.patch("/api/incidents/{incident_id}")
def update_incident(incident_id:int,data:IncidentUpdate,db:Session=Depends(get_db)):
    row=db.get(Incident,incident_id)
    if not row: raise HTTPException(404,"Incident not found")
    if data.status:
        if data.status not in ("Open","In Progress","Resolved"): raise HTTPException(422,"Invalid incident status")
        row.status=data.status
    if data.assigned_to is not None: row.assigned_to=data.assigned_to
    row.updated_at=datetime.now(timezone.utc); db.commit(); log_event(db,"incident_update",f"Incident #{row.id} updated to {row.status}")
    return {"id":row.id,"status":row.status,"assigned_to":row.assigned_to}

@app.post("/api/snapshots")
def create_snapshot(db:Session=Depends(get_db)):
    nodes=db.query(DistributedNode).filter(DistributedNode.status=="online").all()
    # Snapshot is an explicitly marked best-effort cut: collect live node health and durable DB state,
    # and record messages during the bounded capture window. This is not a Chandy-Lamport proof
    # because HTTP channels are not instrumented to record all in-flight messages.
    before=db.query(MessageEvent).count()
    states=[]
    for n in nodes:
        state={"id":n.id,"status":n.status,"clock_value":n.clock_value,"version":n.version}
        try:
            import requests
            response=requests.get(n.address+"/health",timeout=1)
            if response.ok: state["runtime"]=response.json()
        except Exception: state["runtime_unavailable"]=True
        states.append(state)
    messages_now=db.query(MessageEvent).order_by(MessageEvent.id.desc()).limit(50).all()
    sid=str(uuid.uuid4())
    row=Snapshot(snapshot_id=sid,coordinator=get_coordinator(db) or "",state_json=json.dumps({"nodes":states,"reservations":db.query(Reservation).filter(Reservation.status=="confirmed").count()}),
                 message_cut_json=json.dumps([{"id":m.event_id,"type":m.event_type,"sender":m.sender,"receiver":m.receiver} for m in messages_now]),
                 consistent=False)
    db.add(row); db.commit()
    log_event(db,"snapshot",f"Best-effort distributed state capture {sid} created")
    return {"snapshot_id":sid,"coordinator":row.coordinator,"consistent":False,"consistency_note":"Best-effort state capture; not a formally consistent Chandy-Lamport snapshot because in-flight HTTP channels are not fully instrumented.","nodes":states,"message_count_before":before,"message_cut_count":len(messages_now)}

@app.get("/api/snapshots")
def snapshots(db:Session=Depends(get_db)):
    return [{"id":s.id,"snapshot_id":s.snapshot_id,"coordinator":s.coordinator,"consistent":s.consistent,"created_at":dt(s.created_at),"state":json.loads(s.state_json)} for s in db.query(Snapshot).order_by(Snapshot.created_at.desc()).all()]

@app.post("/api/dependencies")
def add_dependency(data:DependencyCreate,db:Session=Depends(get_db)):
    row=ResourceDependency(waiter=data.waiter,holder=data.holder,resource=data.resource,active=True)
    db.add(row); db.commit()
    log_event(db,"dependency",f"{data.waiter} waits for {data.resource} held by {data.holder}")
    return {"id":row.id}

@app.get("/api/deadlocks")
def deadlocks(db:Session=Depends(get_db)):
    edges=[(d.waiter,d.holder) for d in db.query(ResourceDependency).filter(ResourceDependency.active==True).all()]
    return {"edges":[{"waiter":a,"holder":b} for a,b in edges],"cycles":find_cycles(edges)}

@app.get("/api/analytics")
def analytics(db:Session=Depends(get_db)):
    nodes=db.query(DistributedNode).all()
    incidents=db.query(Incident).all()
    reservations=db.query(Reservation).all()
    messages=db.query(MessageEvent).all()
    return {"node_availability":{"online":sum(n.status=="online" for n in nodes),"offline":sum(n.status!="online" for n in nodes)},
            "incidents_by_status":{s:sum(i.status==s for i in incidents) for s in ["Open","In Progress","Resolved"]},
            "incidents_by_severity":{s:sum(i.severity==s for i in incidents) for s in ["Low","Medium","High","Critical"]},
            "reservations_by_status":{s:sum(r.status==s for r in reservations) for s in ["confirmed","cancelled"]},
            "message_count":len(messages),"average_latency_ms":round(sum(n.latency_ms for n in nodes if n.status=="online")/max(1,sum(n.status=="online" for n in nodes)),2)}

@app.get("/api/settings")
def get_settings():
    return {"heartbeat_interval_seconds":settings.heartbeat_interval_seconds,"heartbeat_timeout_seconds":settings.heartbeat_timeout_seconds,
            "database_dialect":engine.dialect.name,"node_base_port":settings.node_base_port}


# ---- Unit II: broker-style durable queued messaging (database-backed) ----
@app.post("/api/broker/publish", status_code=201)
def broker_publish(payload: dict, db: Session=Depends(get_db)):
    message_id=str(uuid.uuid4()); receiver=str(payload.get("receiver","broadcast")); topic=str(payload.get("topic","campus.events"))
    row=QueuedMessage(message_id=message_id,sender=str(payload.get("sender","dashboard")),receiver=receiver,topic=topic,payload=json.dumps(payload.get("payload",{})),status="queued")
    db.add(row); db.commit(); db.refresh(row)
    log_event(db,"broker_publish",f"Queued message {message_id} on topic {topic}")
    return {"message_id":message_id,"status":"queued","topic":topic,"receiver":receiver}

@app.get("/api/broker/consume/{receiver}")
def broker_consume(receiver:str, limit:int=Query(10,ge=1,le=100), db:Session=Depends(get_db)):
    rows=db.query(QueuedMessage).filter(QueuedMessage.status=="queued",QueuedMessage.receiver.in_([receiver,"broadcast"])).order_by(QueuedMessage.id).limit(limit).all()
    now=datetime.now(timezone.utc)
    for row in rows: row.status="delivered"; row.delivered_at=now
    db.commit()
    return [{"message_id":r.message_id,"sender":r.sender,"receiver":r.receiver,"topic":r.topic,"payload":json.loads(r.payload),"created_at":dt(r.created_at)} for r in rows]

@app.get("/api/broker/messages")
def broker_messages(limit:int=Query(100,ge=1,le=500), db:Session=Depends(get_db)):
    rows=db.query(QueuedMessage).order_by(QueuedMessage.id.desc()).limit(limit).all()
    return [{"message_id":r.message_id,"sender":r.sender,"receiver":r.receiver,"topic":r.topic,"payload":json.loads(r.payload),"status":r.status,"created_at":dt(r.created_at),"delivered_at":dt(r.delivered_at)} for r in rows]

# ---- Unit II: direct peer-to-peer HTTP messaging ----
@app.post("/api/p2p/send")
def p2p_send(payload:dict, db:Session=Depends(get_db)):
    sender=str(payload.get("sender","node-1")); receiver=str(payload.get("receiver","node-2")); event=str(payload.get("event_type","P2P_MESSAGE"))
    source=db.get(DistributedNode,sender); target=db.get(DistributedNode,receiver)
    if not source or not target: raise HTTPException(404,"Sender and receiver must both be registered")
    try:
        # The sender node process makes the HTTP request directly to the receiver node.
        response=requests.post(source.address+"/peer-send",json={"address":target.address,"event_type":event,"payload":payload.get("payload",{})},timeout=4)
        response.raise_for_status(); body=response.json()
        log_message(db,sender,receiver,event,clock=int(body.get("clock",0)),payload=payload.get("payload",{}),outcome="ok")
        return {"delivered":True,"transport":"node-to-node HTTP peer-to-peer","sender_process":sender,"receiver":receiver,"response":body}
    except Exception as exc:
        log_message(db,sender,receiver,event,payload=payload.get("payload",{}),outcome="unreachable")
        raise HTTPException(502,f"Peer delivery failed: {exc}")

# ---- Unit III: vector clocks ----
@app.post("/api/clocks/vector/tick")
def vector_clock_tick(payload:dict):
    node_id=str(payload.get("node_id","node-1")); vector=payload.get("vector",{})
    return {"node_id":node_id,"vector":vector_tick(vector,node_id)}

@app.post("/api/clocks/vector/receive")
def vector_clock_receive(payload:dict):
    node_id=str(payload.get("node_id","node-1")); local=payload.get("local",{}); remote=payload.get("remote",{})
    return {"node_id":node_id,"vector":merge_on_receive(local,remote,node_id)}

@app.post("/api/clocks/vector/compare")
def vector_clock_compare(payload:dict):
    return {"relation":compare_vectors(payload.get("a",{}),payload.get("b",{})),"explanation":"before/after indicate causal order; concurrent means neither vector dominates the other."}

# ---- Unit III: fair FIFO mutual exclusion demonstration ----
@app.post("/api/mutex/request")
def mutex_request(payload:dict, db:Session=Depends(get_db)):
    requester=str(payload.get("requester","node-1")); resource=str(payload.get("resource","computer-lab"))
    result=fair_mutex.request(requester,resource)
    # Persist a demonstration ticket record for audit; live lock state is process-local.
    if not db.query(FairMutexTicket).filter(FairMutexTicket.ticket==result['ticket']).first():
        db.add(FairMutexTicket(ticket=result['ticket'],requester=requester,resource=resource,state=result['state'])); db.commit()
    return result

@app.post("/api/mutex/release")
def mutex_release(payload:dict, db:Session=Depends(get_db)):
    try: result=fair_mutex.release(str(payload.get("requester","")),str(payload.get("resource","computer-lab")))
    except ValueError as exc: raise HTTPException(409,str(exc))
    row=db.query(FairMutexTicket).filter(FairMutexTicket.ticket==result['released']['ticket']).first()
    if row: row.state="released"; row.released_at=datetime.now(timezone.utc)
    if result.get('owner'):
        nextrow=db.query(FairMutexTicket).filter(FairMutexTicket.requester==result['owner'],FairMutexTicket.state=='waiting').order_by(FairMutexTicket.ticket).first()
        if nextrow: nextrow.state="granted"
    db.commit(); return result

@app.get("/api/mutex/status")
def mutex_status(): return fair_mutex.status()

@app.get("/api/deadlocks/classification")
def deadlock_classification(db:Session=Depends(get_db)):
    edges=[(d.waiter,d.holder) for d in db.query(ResourceDependency).filter(ResourceDependency.active==True).all()]
    cycles=find_cycles(edges)
    return classify_detection(edges,cycles)

# ---- Unit II: WebRTC signaling for direct browser media/data sessions ----
@app.websocket("/api/webrtc/{room}/{client_id}")
async def webrtc_signaling(websocket:WebSocket, room:str, client_id:str):
    await websocket.accept(); room_peers=webrtc_rooms.setdefault(room,{})
    # Notify peers of arrival, then relay SDP/ICE messages unchanged.
    for peer_id, peer in list(room_peers.items()):
        try: await peer.send_json({"type":"peer-joined","peer_id":client_id})
        except Exception: pass
    room_peers[client_id]=websocket
    try:
        while True:
            message=await websocket.receive_json(); target=message.get("to")
            if target and target in room_peers:
                await room_peers[target].send_json({"from":client_id,**message})
            else:
                for peer_id, peer in list(room_peers.items()):
                    if peer_id!=client_id:
                        await peer.send_json({"from":client_id,**message})
    except WebSocketDisconnect:
        pass
    finally:
        room_peers.pop(client_id,None)
        for peer in list(room_peers.values()):
            try: await peer.send_json({"type":"peer-left","peer_id":client_id})
            except Exception: pass
        if not room_peers: webrtc_rooms.pop(room,None)

# ---- Unit IV: Hadoop Streaming export/integration ----
@app.post("/api/hadoop/export")
def hadoop_export(db:Session=Depends(get_db)):
    from pathlib import Path
    out=Path(__file__).resolve().parents[2]/"data"/"hadoop"/"campus_events.jsonl"; out.parent.mkdir(parents=True,exist_ok=True)
    events=db.query(SystemEvent).order_by(SystemEvent.id).all()
    messages=db.query(MessageEvent).order_by(MessageEvent.id).all()
    with out.open("w",encoding="utf-8") as fp:
        for e in events: fp.write(json.dumps({"kind":"system_event","category":e.category,"message":e.message,"timestamp":dt(e.timestamp)})+"\n")
        for m in messages: fp.write(json.dumps({"kind":"message","event_type":m.event_type,"sender":m.sender,"receiver":m.receiver,"outcome":m.outcome,"timestamp":dt(m.timestamp)})+"\n")
    return {"exported":len(events)+len(messages),"path":str(out.relative_to(Path(__file__).resolve().parents[2])),"format":"JSON Lines","next_step":"Run scripts/hadoop/run_hadoop_streaming.sh against a Hadoop installation/cluster."}

@app.get("/api/hadoop/manifest")
def hadoop_manifest():
    return {"integration":"Apache Hadoop Streaming MapReduce","input":"data/hadoop/campus_events.jsonl","mapper":"scripts/hadoop/mapper.py","reducer":"scripts/hadoop/reducer.py","job":"scripts/hadoop/run_hadoop_streaming.sh","purpose":"Count event categories and message types across exported campus telemetry.","requires_external_hadoop":True}
