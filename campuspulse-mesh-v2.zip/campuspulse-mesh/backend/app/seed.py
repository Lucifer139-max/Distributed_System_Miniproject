from datetime import datetime, timedelta, timezone
import uuid
from sqlalchemy.orm import Session
from .models import Facility, Resource, DistributedNode, Incident, SystemEvent

FACILITIES = [
 ("Computer Lab 1","Computer Labs",30,"Computer Center","PCs, Projector, AC","computer-lab"),
 ("Computer Lab 2","Computer Labs",25,"Computer Center","PCs, GPUs, AC","computer-lab"),
 ("Seminar Room A","Seminar Rooms",100,"Admin Block","Projector, Audio, AC","seminar-room"),
 ("Seminar Room B","Seminar Rooms",50,"Admin Block","Projector, Whiteboard","seminar-room"),
 ("Library","Library",200,"Library Block","Study Halls, PCs, WiFi","library"),
 ("Hostel (Common Room)","Hostel",40,"Hostel Block","TV, Seating, WiFi","hostel"),
 ("3D Printer (Maker Space)","Equipment",1,"Research Center","MakerBot Replicator; Student Projects","printer"),
 ("Electronics Lab","Research Center",25,"Engineering Block","Oscilloscopes, Kits","electronics-lab"),
]
NODES = [
 ("node-1","Admin Block",8101,1), ("node-2","Computer Lab",8102,2),
 ("node-3","Library",8103,3), ("node-4","Hostel",8104,4),
 ("node-5","Research Center",8105,5), ("node-6","Sports Complex",8106,6)
]
INCIDENTS = [
 ("Network outage in Hostel block","Critical","Hostel","Node Monitor","Open","No network connectivity in Hostel building. All systems offline."),
 ("AC not working in Lab 2","Medium","Computer Lab","Lab Admin","In Progress","Air conditioning is not cooling the lab."),
 ("Projector issue in Seminar Room A","Low","Admin Block","Faculty","Open","Projector output flickers intermittently."),
 ("Power fluctuation in Research Center","High","Research Center","Maintenance","In Progress","Power fluctuations reported in the research wing."),
 ("WiFi not working in Library","Medium","Library","Student","Resolved","Access point restarted and connectivity restored."),
 ("3D Printer not working","Medium","Research Center","Lab Admin","Resolved","Filament feed was cleaned."),
 ("Door lock malfunction","Low","Admin Block","Security","Resolved","Door lock repaired."),
]
def seed(db: Session):
    if db.query(Facility).count() == 0:
        for name, cat, cap, loc, equip, key in FACILITIES:
            f=Facility(name=name, category=cat, capacity=cap, location=loc, equipment=equip, image_key=key)
            db.add(f); db.flush()
            db.add(Resource(facility_id=f.id, name=name, capacity=cap, kind=cat))
    if db.query(DistributedNode).count() == 0:
        for nid, facility, port, priority in NODES:
            db.add(DistributedNode(id=nid, facility=facility, address=f"http://127.0.0.1:{port}", priority=priority, status="offline"))
    if db.query(Incident).count() == 0:
        for title, sev, facility, reporter, status, desc in INCIDENTS:
            db.add(Incident(title=title, severity=sev, facility=facility, reported_by=reporter, status=status, description=desc,
                            created_at=datetime.now(timezone.utc)-timedelta(hours=2)))
    if db.query(SystemEvent).count() == 0:
        db.add(SystemEvent(event_id=str(uuid.uuid4()), category="system", message="CampusPulse Mesh database seeded", node_id=None))
    db.commit()
