from datetime import datetime, timezone
from sqlalchemy import String, Integer, Float, DateTime, Boolean, ForeignKey, Text, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

def now():
    return datetime.now(timezone.utc)

class Facility(Base):
    __tablename__ = "facilities"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(60), index=True)
    capacity: Mapped[int] = mapped_column(Integer, default=0)
    location: Mapped[str] = mapped_column(String(120))
    equipment: Mapped[str] = mapped_column(Text, default="")
    image_key: Mapped[str] = mapped_column(String(120), default="")
    node_id: Mapped[str | None] = mapped_column(String(40), nullable=True)

class Resource(Base):
    __tablename__ = "resources"
    id: Mapped[int] = mapped_column(primary_key=True)
    facility_id: Mapped[int] = mapped_column(ForeignKey("facilities.id"), index=True)
    name: Mapped[str] = mapped_column(String(120), index=True)
    capacity: Mapped[int] = mapped_column(Integer, default=0)
    kind: Mapped[str] = mapped_column(String(60), default="facility")

class DistributedNode(Base):
    __tablename__ = "distributed_nodes"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    facility: Mapped[str] = mapped_column(String(120))
    address: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default="offline", index=True)
    priority: Mapped[int] = mapped_column(Integer)
    last_heartbeat: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    clock_value: Mapped[int] = mapped_column(Integer, default=0)
    cpu_percent: Mapped[float] = mapped_column(Float, default=0)
    memory_percent: Mapped[float] = mapped_column(Float, default=0)
    latency_ms: Mapped[float] = mapped_column(Float, default=0)
    last_error: Mapped[str] = mapped_column(Text, default="")
    version: Mapped[int] = mapped_column(Integer, default=0)

class Reservation(Base):
    __tablename__ = "reservations"
    __table_args__ = (Index("ix_reservation_resource_time", "resource_id", "start_at", "end_at"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    requester: Mapped[str] = mapped_column(String(120))
    resource_id: Mapped[int] = mapped_column(ForeignKey("resources.id"), index=True)
    facility_name: Mapped[str] = mapped_column(String(120))
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    purpose: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="confirmed", index=True)
    request_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Incident(Base):
    __tablename__ = "incidents"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    severity: Mapped[str] = mapped_column(String(20), default="Medium", index=True)
    facility: Mapped[str] = mapped_column(String(120), index=True)
    reported_by: Mapped[str] = mapped_column(String(120), default="Admin")
    status: Mapped[str] = mapped_column(String(30), default="Open", index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    assigned_to: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)

class MessageEvent(Base):
    __tablename__ = "message_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    sender: Mapped[str] = mapped_column(String(40))
    receiver: Mapped[str] = mapped_column(String(40))
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    clock_value: Mapped[int] = mapped_column(Integer, default=0)
    outcome: Mapped[str] = mapped_column(String(40), default="ok")
    payload: Mapped[str] = mapped_column(Text, default="{}")

class SystemEvent(Base):
    __tablename__ = "system_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    category: Mapped[str] = mapped_column(String(80), index=True)
    message: Mapped[str] = mapped_column(Text)
    node_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)

class CoordinatorElection(Base):
    __tablename__ = "coordinator_elections"
    id: Mapped[int] = mapped_column(primary_key=True)
    initiator: Mapped[str] = mapped_column(String(40))
    coordinator: Mapped[str] = mapped_column(String(40))
    participants: Mapped[str] = mapped_column(Text, default="[]")
    reason: Mapped[str] = mapped_column(Text, default="")
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Snapshot(Base):
    __tablename__ = "snapshots"
    id: Mapped[int] = mapped_column(primary_key=True)
    snapshot_id: Mapped[str] = mapped_column(String(80), unique=True)
    coordinator: Mapped[str] = mapped_column(String(40), default="")
    state_json: Mapped[str] = mapped_column(Text)
    message_cut_json: Mapped[str] = mapped_column(Text, default="[]")
    consistent: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class PendingUpdate(Base):
    __tablename__ = "pending_updates"
    id: Mapped[int] = mapped_column(primary_key=True)
    update_id: Mapped[str] = mapped_column(String(80), unique=True)
    node_id: Mapped[str] = mapped_column(String(40), index=True)
    version: Mapped[int] = mapped_column(Integer)
    payload: Mapped[str] = mapped_column(Text)
    applied: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ResourceDependency(Base):
    __tablename__ = "resource_dependencies"
    id: Mapped[int] = mapped_column(primary_key=True)
    waiter: Mapped[str] = mapped_column(String(120), index=True)
    holder: Mapped[str] = mapped_column(String(120), index=True)
    resource: Mapped[str] = mapped_column(String(120))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class QueuedMessage(Base):
    __tablename__ = "queued_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    message_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    sender: Mapped[str] = mapped_column(String(80))
    receiver: Mapped[str] = mapped_column(String(80), index=True)
    topic: Mapped[str] = mapped_column(String(120), index=True)
    payload: Mapped[str] = mapped_column(Text, default="{}")
    status: Mapped[str] = mapped_column(String(20), default="queued", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class FairMutexTicket(Base):
    __tablename__ = "fair_mutex_tickets"
    id: Mapped[int] = mapped_column(primary_key=True)
    ticket: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    requester: Mapped[str] = mapped_column(String(80), index=True)
    resource: Mapped[str] = mapped_column(String(120), index=True)
    state: Mapped[str] = mapped_column(String(20), default="waiting", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
