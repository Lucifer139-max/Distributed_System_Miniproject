import os
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./campuspulse.db"
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    heartbeat_interval_seconds: float = 3.0
    heartbeat_timeout_seconds: float = 10.0
    node_base_port: int = 8101
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
