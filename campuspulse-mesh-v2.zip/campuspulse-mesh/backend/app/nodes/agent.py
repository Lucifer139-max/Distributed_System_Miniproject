import argparse, asyncio, os, socket, time, uuid
from datetime import datetime, timezone
import httpx
import psutil
from ..algorithms.lamport import LamportClock
from ..algorithms.vector_clock import tick as vector_tick, merge_on_receive

async def run_node(node_id: str, facility: str, port: int, api_url: str):
    import uvicorn
    from fastapi import FastAPI
    from pydantic import BaseModel
    clock = LamportClock()
    vector_clock = {node_id: 0}
    app = FastAPI(title=f"CampusPulse {node_id}")
    started = time.monotonic()
    class Message(BaseModel):
        sender: str
        event_type: str
        clock_value: int = 0
        payload: dict = {}
    @app.get("/health")
    async def health():
        return {"id": node_id, "facility": facility, "status": "online", "clock": clock.value,
                "uptime_seconds": round(time.monotonic()-started, 2), "vector_clock": vector_clock, "timestamp": datetime.now(timezone.utc).isoformat()}
    @app.post("/message")
    async def receive(message: Message):
        new_clock = clock.receive(message.clock_value)
        nonlocal vector_clock
        remote_vector = message.payload.get("vector_clock", {}) if isinstance(message.payload, dict) else {}
        vector_clock = merge_on_receive(vector_clock, remote_vector, node_id)
        return {"received": True, "node_id": node_id, "clock": new_clock, "vector_clock": vector_clock, "event_type": message.event_type}
    @app.post("/tick")
    async def tick():
        return {"node_id": node_id, "clock": clock.tick(), "vector_clock": vector_tick(vector_clock, node_id)}
    @app.post("/peer-send")
    async def peer_send(body: dict):
        target = str(body.get("address", "")).rstrip("/")
        if not target:
            return {"delivered": False, "error": "address is required"}
        clock.tick()
        vector_clock.update(vector_tick(vector_clock, node_id))
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.post(target + "/message", json={
                "sender": node_id,
                "event_type": str(body.get("event_type", "P2P_MESSAGE")),
                "clock_value": clock.value,
                "payload": {**body.get("payload", {}), "vector_clock": vector_clock}
            })
            response.raise_for_status()
            reply = response.json()
            if reply.get("vector_clock"):
                vector_clock.update(merge_on_receive(vector_clock, reply["vector_clock"], node_id))
            return {"delivered": True, "sender": node_id, "receiver": reply.get("node_id"), "clock": clock.value, "vector_clock": vector_clock, "peer_response": reply}
    async def heartbeat_loop():
        async with httpx.AsyncClient(timeout=2.0) as client:
            while True:
                try:
                    clock.tick()
                    vector_clock.update(vector_tick(vector_clock, node_id))
                    cpu = psutil.cpu_percent(interval=None)
                    memory = psutil.virtual_memory().percent
                    started_at = time.monotonic()
                    await client.post(f"{api_url}/api/nodes/{node_id}/heartbeat",
                        json={"clock_value": clock.value, "cpu_percent": cpu, "memory_percent": memory, "latency_ms": round((time.monotonic()-started_at)*1000, 2), "vector_clock": vector_clock})
                    queued = await client.get(f"{api_url}/api/broker/consume/{node_id}")
                    for msg in queued.json():
                        clock.receive(msg.get("payload", {}).get("clock_value", 0))
                except Exception:
                    pass
                await asyncio.sleep(float(os.getenv("HEARTBEAT_INTERVAL_SECONDS", "3")))
    @app.on_event("startup")
    async def startup():
        async def register():
            async with httpx.AsyncClient(timeout=3.0) as client:
                for _ in range(10):
                    try:
                        await client.post(f"{api_url}/api/nodes/register", json={"id": node_id, "facility": facility,
                            "address": f"http://127.0.0.1:{port}", "priority": int(node_id.split("-")[-1])})
                        break
                    except Exception:
                        await asyncio.sleep(1)
        asyncio.create_task(register())
        asyncio.create_task(heartbeat_loop())
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    await uvicorn.Server(config).serve()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--id", required=True); parser.add_argument("--facility", required=True)
    parser.add_argument("--port", required=True, type=int)
    parser.add_argument("--api-url", default=os.getenv("API_URL", "http://127.0.0.1:8000"))
    args=parser.parse_args()
    asyncio.run(run_node(args.id, args.facility, args.port, args.api_url))
if __name__ == "__main__":
    main()
