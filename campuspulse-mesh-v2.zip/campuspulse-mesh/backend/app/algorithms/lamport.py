class LamportClock:
    def __init__(self, value: int = 0):
        self.value = value

    def tick(self) -> int:
        self.value += 1
        return self.value

    def receive(self, remote_value: int) -> int:
        self.value = max(self.value, int(remote_value)) + 1
        return self.value
