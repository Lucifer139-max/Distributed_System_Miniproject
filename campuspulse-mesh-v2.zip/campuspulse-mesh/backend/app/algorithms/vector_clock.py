from __future__ import annotations
from typing import Dict

def tick(vector: Dict[str, int], node_id: str) -> dict[str, int]:
    result={str(k):int(v) for k,v in vector.items()}; result[node_id]=result.get(node_id,0)+1; return result

def merge_on_receive(local: Dict[str,int], remote: Dict[str,int], receiver_id: str) -> dict[str,int]:
    merged={k:max(int(local.get(k,0)),int(remote.get(k,0))) for k in set(local)|set(remote)}
    merged[receiver_id]=merged.get(receiver_id,0)+1
    return dict(sorted(merged.items()))

def compare(a: Dict[str,int], b: Dict[str,int]) -> str:
    keys=set(a)|set(b); le=all(int(a.get(k,0))<=int(b.get(k,0)) for k in keys); ge=all(int(a.get(k,0))>=int(b.get(k,0)) for k in keys)
    if le and ge: return 'equal'
    if le: return 'before'
    if ge: return 'after'
    return 'concurrent'
