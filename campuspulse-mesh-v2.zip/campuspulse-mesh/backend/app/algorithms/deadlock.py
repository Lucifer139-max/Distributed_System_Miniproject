def find_cycles(edges: list[tuple[str, str]]) -> list[list[str]]:
    """Find directed cycles in a wait-for graph (waiter -> holder)."""
    graph: dict[str, list[str]] = {}
    for a, b in edges:
        graph.setdefault(a, []).append(b)
        graph.setdefault(b, [])
    cycles, stack, visiting, visited = [], [], set(), set()
    def dfs(node):
        visiting.add(node); stack.append(node)
        for nxt in graph.get(node, []):
            if nxt in visiting:
                cycle = stack[stack.index(nxt):] + [nxt]
                canonical = tuple(cycle)
                if not any(tuple(c) == canonical or (len(c) == len(cycle) and set(c[:-1]) == set(cycle[:-1])) for c in cycles):
                    cycles.append(cycle)
            elif nxt not in visited:
                dfs(nxt)
        stack.pop(); visiting.remove(node); visited.add(node)
    for node in graph:
        if node not in visited:
            dfs(node)
    return cycles
