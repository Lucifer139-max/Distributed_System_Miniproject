def bully_election(nodes: list[dict], initiator_id: str) -> dict:
    """Pure Bully election decision: highest-priority live node wins.
    Network message exchange is performed by the node/API service layer.
    """
    active = [n for n in nodes if n.get("status") == "online"]
    if not active:
        raise ValueError("No online nodes are eligible to coordinate")
    by_id = {n["id"]: n for n in active}
    if initiator_id not in by_id:
        raise ValueError(f"Initiator {initiator_id} is not online")
    higher = [n for n in active if int(n["priority"]) > int(by_id[initiator_id]["priority"])]
    winner = max(active, key=lambda n: int(n["priority"]))
    return {"coordinator": winner["id"], "participants": [n["id"] for n in active],
            "higher_priority_responses": [n["id"] for n in higher]}
