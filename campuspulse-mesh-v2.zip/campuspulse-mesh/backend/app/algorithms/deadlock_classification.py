def classify_detection(edges, cycles):
    """Educational mapping to common distributed deadlock detector families."""
    vertices={x for edge in edges for x in edge}
    return {
      'current_algorithm':'centralized wait-for graph cycle detection',
      'graph_type':'wait-for graph',
      'vertices':len(vertices), 'edges':len(edges), 'cycles_detected':len(cycles),
      'knapp_taxonomy_note':'Knapp-style taxonomy is presented for study. The running detector remains centralized wait-for graph cycle detection; the other families below are conceptual comparisons.',
      'knapp_families':[
        {'name':'Path-pushing','description':'Processes propagate dependency paths to help discover cycles.','implemented':False},
        {'name':'Edge-chasing','description':'Probe messages travel along wait-for edges and return to an initiator when a cycle is found.','implemented':False},
        {'name':'Diffusion computation','description':'A query is diffused through dependent processes and replies are collected.','implemented':False},
        {'name':'Global-state detection','description':'A detector collects a global dependency/state view and checks it for cycles.','implemented':True}
      ],
      'families':[
        {'name':'Centralized','description':'One detector collects dependency edges and searches for cycles.','implemented':True},
        {'name':'Hierarchical','description':'Regional detectors summarize dependencies to higher-level detectors.','implemented':False},
        {'name':'Fully distributed','description':'Processes cooperate by exchanging probes or dependency information.','implemented':False}
      ]
    }
