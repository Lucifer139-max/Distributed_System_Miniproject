"""FIFO ticket-based distributed mutual-exclusion coordinator.

This is an explicit fair queue-based mutual exclusion implementation for the demo.
It is not a verbatim implementation of the published Lodha–Kshemkalyani protocol.
"""
from dataclasses import dataclass, field
from threading import RLock
from time import time

@dataclass
class FairMutex:
    _lock: RLock = field(default_factory=RLock)
    _next_ticket: int = 1
    _queue: list = field(default_factory=list)
    _owner: str | None = None

    def request(self, requester: str, resource: str) -> dict:
        with self._lock:
            existing=next((x for x in self._queue if x['requester']==requester and x['resource']==resource),None)
            if existing: return {**existing,'owner':self._owner,'position':self._queue.index(existing)+1}
            row={'ticket':self._next_ticket,'requester':requester,'resource':resource,'requested_at':time(),'state':'waiting'}
            self._next_ticket+=1; self._queue.append(row)
            if self._owner is None: self._grant_next()
            row['position']=self._queue.index(row)+1 if row in self._queue else 0
            return {**row,'owner':self._owner}

    def _grant_next(self):
        if self._queue:
            self._queue[0]['state']='granted'; self._owner=self._queue[0]['requester']
        else: self._owner=None

    def release(self, requester: str, resource: str) -> dict:
        with self._lock:
            if not self._queue or self._queue[0]['requester']!=requester or self._queue[0]['resource']!=resource:
                raise ValueError('Only the current lock owner can release this resource')
            released=self._queue.pop(0); self._owner=None; self._grant_next()
            return {'released':released,'owner':self._owner,'queue':self.status()['queue']}

    def status(self):
        with self._lock:
            return {'owner':self._owner,'queue':[dict(x,position=i+1) for i,x in enumerate(self._queue)],'next_ticket':self._next_ticket,'fairness':'FIFO ticket order'}
