from app.algorithms.vector_clock import tick, merge_on_receive, compare
from app.algorithms.fair_mutex import FairMutex

def test_vector_clock_causality_and_concurrency():
    assert tick({'a':1},'a')=={'a':2}
    assert merge_on_receive({'a':1},{'b':2},'a')=={'a':2,'b':2}
    assert compare({'a':1},{'a':2})=='before'
    assert compare({'a':1},{'b':1})=='concurrent'

def test_fair_mutex_fifo_grant_and_release():
    lock=FairMutex()
    a=lock.request('node-1','lab'); b=lock.request('node-2','lab'); c=lock.request('node-3','lab')
    assert a['state']=='granted' and b['state']=='waiting' and c['state']=='waiting'
    result=lock.release('node-1','lab')
    assert result['owner']=='node-2'
    assert lock.release('node-2','lab')['owner']=='node-3'
