import pytest
from app.algorithms.lamport import LamportClock
from app.algorithms.bully import bully_election
from app.algorithms.deadlock import find_cycles

def test_lamport_tick_and_receive():
    c=LamportClock(4)
    assert c.tick()==5
    assert c.receive(10)==11
    assert c.tick()==12

def test_bully_highest_online_priority_wins():
    nodes=[{"id":"node-1","priority":1,"status":"online"},
           {"id":"node-2","priority":2,"status":"online"},
           {"id":"node-3","priority":3,"status":"offline"},
           {"id":"node-4","priority":4,"status":"online"}]
    result=bully_election(nodes,"node-1")
    assert result["coordinator"]=="node-4"
    assert set(result["participants"])=={"node-1","node-2","node-4"}

def test_bully_rejects_offline_initiator():
    with pytest.raises(ValueError):
        bully_election([{"id":"node-1","priority":1,"status":"offline"}],"node-1")

def test_deadlock_cycle_and_acyclic_graph():
    assert find_cycles([("A","B"),("B","C"),("C","A")])
    assert find_cycles([("A","B"),("B","C")])==[]

def test_deadlock_multiple_components():
    cycles=find_cycles([("A","B"),("B","A"),("C","D"),("D","C")])
    assert len(cycles)==2
