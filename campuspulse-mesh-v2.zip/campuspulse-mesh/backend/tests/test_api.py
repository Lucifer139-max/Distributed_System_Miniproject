import os
os.environ["DATABASE_URL"]="sqlite:///./test_campuspulse.db"
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine

def setup_module():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

def test_health_and_facilities():
    with TestClient(app) as client:
        assert client.get("/api/health").status_code==200
        response=client.get("/api/facilities")
        assert response.status_code==200
        assert len(response.json())>=8

def test_deadlock_api_empty():
    with TestClient(app) as client:
        assert client.get("/api/deadlocks").status_code==200

def test_conflicting_reservation_rejected():
    from datetime import datetime, timedelta, timezone
    with TestClient(app) as client:
        resources=client.get('/api/resources').json()
        assert resources
        start=(datetime.now(timezone.utc)+timedelta(days=2)).replace(hour=10,minute=0,second=0,microsecond=0)
        end=start+timedelta(hours=1)
        payload={"requester":"Test User","resource_id":resources[0]["id"],"start_at":start.isoformat(),"end_at":end.isoformat(),"purpose":"integration test booking"}
        first=client.post('/api/reservations',json=payload)
        assert first.status_code==201, first.text
        payload2={**payload,"requester":"Second Test User","purpose":"conflicting booking"}
        second=client.post('/api/reservations',json=payload2)
        assert second.status_code==409, second.text


def test_bully_election_endpoint_persists_highest_online_node():
    with TestClient(app) as client:
        for nid, facility, port, priority in [("node-1", "Admin Block", 8101, 1), ("node-2", "Computer Lab", 8102, 2), ("node-3", "Library", 8103, 3)]:
            response=client.post('/api/nodes/register',json={"id":nid,"facility":facility,"address":f"http://127.0.0.1:{port}","priority":priority})
            assert response.status_code==200
        result=client.post('/api/elections',json={"initiator":"node-1"})
        assert result.status_code==200
        assert result.json()['coordinator']=='node-3'
        assert result.json()['algorithm']=='Bully'

def test_extended_distributed_features():
    with TestClient(app) as client:
        queued=client.post('/api/broker/publish',json={'sender':'dashboard','receiver':'node-1','topic':'test.events','payload':{'hello':'world'}})
        assert queued.status_code==201 and queued.json()['status']=='queued'
        consumed=client.get('/api/broker/consume/node-1')
        assert consumed.status_code==200 and any(x['topic']=='test.events' for x in consumed.json())
        vector=client.post('/api/clocks/vector/receive',json={'node_id':'node-1','local':{'node-1':1},'remote':{'node-2':3}})
        assert vector.status_code==200 and vector.json()['vector']=={'node-1':2,'node-2':3}
        compare=client.post('/api/clocks/vector/compare',json={'a':{'node-1':1},'b':{'node-2':1}})
        assert compare.json()['relation']=='concurrent'
        req1=client.post('/api/mutex/request',json={'requester':'test-A','resource':'test-lab'})
        req2=client.post('/api/mutex/request',json={'requester':'test-B','resource':'test-lab'})
        assert req1.status_code==200 and req1.json()['state']=='granted'
        assert req2.status_code==200 and req2.json()['state']=='waiting'
        rel=client.post('/api/mutex/release',json={'requester':'test-A','resource':'test-lab'})
        assert rel.status_code==200 and rel.json()['owner']=='test-B'
        classification=client.get('/api/deadlocks/classification')
        assert classification.status_code==200 and classification.json()['families'][0]['implemented'] is True
        export=client.post('/api/hadoop/export')
        assert export.status_code==200 and export.json()['format']=='JSON Lines'
        assert client.get('/api/hadoop/manifest').status_code==200
